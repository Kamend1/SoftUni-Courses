create function interval_pl_timestamp(interval, timestamp without time zone) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN ($2 + $1);

comment on function interval_pl_timestamp(interval, timestamp) is 'implementation of + operator';

alter function interval_pl_timestamp(interval, timestamp) owner to "Kamend1";

